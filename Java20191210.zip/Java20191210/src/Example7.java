import java.util.Scanner;
public class Example7 {
	public static void main(String[] args) {
		Scanner scn = new Scanner(System.in);
		int begin, end, step;
		System.out.println("Enter beginning integer value:");
		begin = scn.nextInt();
		System.out.println("Enter ending integer value:");
		end = scn.nextInt();
		System.out.println("Enter increment integer value:");
		step = scn.nextInt();
		for (int i = begin; i <= end; i += step)
		{
			System.out.print(i + " ");
		}
	}
}
public class Example6 {
	public static void main(String[] args) {
		for (int i = 100; i >= 0; --i)
		{
			System.out.print(i + " ");
		}
		System.out.println("----------");
		for (int i = 0; i <= 100; ++i) //print even numbers
		{
			if (i %2 == 0)
			{
				System.out.print(i + " ");
			}			
		}
		System.out.println("----------");
		for (int i = 0; i <= 100; ++i) //print odd numbers
		{
			if (i %2 == 1)
			{
				System.out.print(i + " ");
			}			
		}
	}
}
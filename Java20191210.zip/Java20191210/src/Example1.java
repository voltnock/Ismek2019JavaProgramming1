public class Example1 {
	public static void main(String[] args) {
		String name = "test";
		System.out.println(name.charAt(0));
		String text = null;
		try
		{
			System.out.println(text.charAt(0)); //NullPointerException
		}
		catch (NullPointerException e)
		{
			System.out.println("text variable is null, NullPointerException worked.");
			//Value of an undefined variable cannot be reached.
		}
	}
}
import java.util.Scanner;
import java.util.Random;
public class Example8 {
	public static void main(String[] args) {
		int number = 0;
		for(;;) //infinite loop
		{
			number++;
			System.out.print(number + " ");
			if (number == 20)
			{
				break;
			}
		}
		System.out.println("----------");
		int number2 = 0;
		while (true) //infinite loop
		{
			System.out.print("Hello!" + " ");
			number2++;
			if (number2 == 10)
			{
				break;
			}
		}
		System.out.println("----------");
		for (int i = 0; i < 10; i++)
		{
			if (i==5)
			{
				continue; //Skips the value and continues from the next value.
			}
			System.out.print(i + " ");
		}
	}
}
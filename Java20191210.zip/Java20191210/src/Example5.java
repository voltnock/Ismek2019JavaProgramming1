import java.util.Scanner;
public class Example5 {
	public static void main(String[] args) {
		Scanner scn = new Scanner(System.in);
		System.out.println("How many numbers will you input?");		
		int length = 0;
		try
		{
			length = scn.nextInt();
		}
		catch (Exception e)
		{
			System.out.println(e.toString());
		}
		double[] arr = new double[length];
		for (int i = 0; i < arr.length; ++i)
		{
			System.out.println("Enter number order " + (i + 1));
			arr[i] = scn.nextDouble();
		}
		for (int i = 0; i < arr.length; ++i)
		{
			if (i != (arr.length - 1))
			{
				System.out.print(arr[i] + ", ");
			}
			else
			{
				System.out.println(arr[i]);
			}
		}
	}
}
public class Example2 {
	public static void main(String[] args) {
		String num = "100a";
		try
		{
			int number = Integer.parseInt(num);
		}
		catch (Exception e)
		{
			System.out.println(e.toString()); //NumberFormatException
		}
		String[] arr = new String[5];
		try
		{
			System.out.println(arr[8]);
		}
		catch (Exception e)
		{
			System.out.println(e.toString()); //ArrayIndexOutOfBoundsException
		}
		
	}
}
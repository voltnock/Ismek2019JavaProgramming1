import java.io.IOException;
public class Example3 {
	public static void readTextFromFile (String fileAddress) throws IOException
	{
		
	}
	public static void main(String[] args) {
		// throws keyword
		try
		{
			readTextFromFile("");
		} 
		catch (IOException e)
		{
			e.printStackTrace();
		}
	}
}
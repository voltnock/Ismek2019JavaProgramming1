import java.util.Scanner;
public class Example4 {
	public static void main(String[] args) {
		Scanner scn = new Scanner(System.in);
		String[] text = new String[5];
		System.out.println("Enter text number 1");
		text[0] = scn.nextLine();
		System.out.println("Enter text number 2");
		text[1] = scn.nextLine();
		System.out.println("Enter text number 3");
		text[2] = scn.nextLine();
		System.out.println("Enter text number 4");
		text[3] = scn.nextLine();
		System.out.println("Enter text number 5");
		text[4] = scn.nextLine();
		System.out.print(text[0] + " ");
		System.out.print(text[1] + " ");
		System.out.print(text[2] + " ");
		System.out.print(text[3] + " ");
		System.out.println(text[4]);
	}
}
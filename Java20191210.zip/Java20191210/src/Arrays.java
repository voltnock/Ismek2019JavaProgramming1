public class Arrays {
	public static void main(String[] args) {
		int[] numArray = new int[10];
		int[] numArr = {1, 2, 3, 4, 5};
		String[] textArray = new String[5];
		numArray[0] = 1;
		numArray[1] = 2;
		numArray[2] = 3;
		numArray[3] = 4;
		numArray[4] = 5;
		//If an array type of int has indices without assigned value, the default value is 0.
		//If an array type of String has indices without assigned value, the default value is null.
		textArray[0] = "Ismek";
		textArray[1] = "Fatih";
		textArray[2] = "IT";
		textArray[3] = "School";
		for (int i = 0; i < numArray.length; ++i)
		{
			System.out.print(numArray[i] + " ");
		}
		for (int i = 0; i < textArray.length; ++i)
		{
			System.out.print(textArray[i] + " ");
		}
	}
}
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
public class Example7
{
	public static void main(String[] args)
	{
		// FileInputStream is a class used to read file
		// FileOutoutStream is a class used to write to file
		File file = new File("Z:/JavaFileOperations/text.txt");
		try
		{
			FileInputStream fis = new FileInputStream(file);
			int ch = 0;
			try
			{
				while ((ch = fis.read()) != -1) // -1 means FileInputStream has reached end.
				//read() method reads values character by character. Each character is in int type.
				//It is necessary to cast to char type to read their character values.
				{
					System.out.print((char)ch);
				}
			}
			catch (IOException e)
			{
				e.printStackTrace();
			}
		}
		catch (FileNotFoundException e)
		{
			e.printStackTrace();
		}
		
	}
}
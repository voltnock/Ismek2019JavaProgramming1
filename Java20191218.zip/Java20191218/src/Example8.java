import java.io.File;
public class Example8
{
	public static void main(String[] args)
	{
		File file = new File("Z:/JavaFileOperations/trial.txt");
		if (file.exists())
		{
			System.out.println("Is this a file? " + file.isFile());
			System.out.println("Is this a folder? " + file.isDirectory());
			System.out.println("Is this hidden? " + file.isHidden());
			if (file.isFile())
			{
				System.out.println("File's character length: " + file.length());
			}
		}
	}
}
import java.io.File;
public class Example4 //File class methods
{
	public static void main(String[] args)
	{
		File file = new File("Z:/JavaFileOperations/trial"); //points working folder
		/*
		canRead - boolean
		canWrite - boolean
		canExecute - boolean
		exists - boolean
		createNewFile - Creates a new file
		delete  - Deletes file or folder, returns boolean
		getAbsolutePath - returns directory path
		getName - returns file or directory name
		getPath - returns working directory
		isDirectory - boolean
		isFile - boolean
		isHidden - boolean
		lastModified - returns long, indicating last modified time
		length - returns long, indicating number of characters in file
		list - returns String[], names of files and folders in directory
		listFiles - returns File[], all values in directory stored in an array as File
		mkDir - creates a folder
		renameTo - renames files or folders
		*/
		if (file.delete())
		{
			System.out.println("File/folder was deleted.");
		}
		else
		{
			System.out.println("File/folder couldn't be deleted.");
		}
	}
}
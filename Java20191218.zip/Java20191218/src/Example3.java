import java.util.regex.Pattern;
public class Example3
{
	public static boolean isValidEmail(String email)
    {
        String emailRegex = "^[a-zA-Z0-9_+&*-]+(?:\\." + "[a-zA-Z0-9_+&*-]+)*@" + "(?:[a-zA-Z0-9-]+\\.)+[a-z" + "A-Z]{2,7}$";
        Pattern pat = Pattern.compile(emailRegex);
        if (email == null)
        {
        	return false; 
        }
        return pat.matcher(email).matches(); 
    }
	public static String returnType(String str)
	{
		String result = "";
		if ((str.startsWith("http://") || str.startsWith("https://") || str.startsWith("ftp://")) && str.contains("."))
		{
			result = "'" + str + "' String can be a website or ftp address.";
		}
		else if (str.startsWith("+") && str.length() >= 7)
		{
			int counter = 0;
			String numbers = "0123456789";
			for (int i = 1; i < str.length(); ++i)
			{
				for (int j = 0; j < numbers.length(); ++j)
				{
					if (str.charAt(i) == numbers.charAt(j))
					{
						++counter;
					}
				}
			}
			int telNumLength = str.length() - 1;
			if (counter == telNumLength)
			{
				result = "'" + str + "' String can be a telephone number.";
			}
		}
		else if (str.charAt(0) != '@' && str.contains("@") && str.contains(".") && !str.endsWith(".") && isValidEmail(str))
		{
			result = "'" + str + "' String can be an e-mail address.";
		}
		return result;
	}
	public static void main(String[] args)
	{
		System.out.println(returnType("http://serifgungor.com"));
		System.out.println(returnType("+902120001122"));
		System.out.println(returnType("contact@serifgungor.com"));
	}
}
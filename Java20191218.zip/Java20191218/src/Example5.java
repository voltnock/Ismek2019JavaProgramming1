import java.io.File;
import java.io.IOException;
public class Example5
{
	public static void createTenFiles()
	{
		File file = new File("Z:/JavaFileOperations");
		if (file.exists())
		{
			System.out.println("Directory was found.");
			for (int i = 1; i <= 10; ++i)
			{
				File txtFile = new File("Z:/JavaFileOperations/file_" + i + ".txt");
				try
				{
					boolean b = txtFile.createNewFile();
					if (b)
					{
						System.out.println("file_" + i + ".txt was successfully created.");
					}
					else
					{
						System.out.println("file_" + i + ".txt couldn't be created.");
					}
				}
				catch (IOException e)
				{
					e.printStackTrace();
				}
			}
		}
		else
		{
			System.out.println("Directory couldn't be found.");
		}
	}
	public static void deleteTenFiles()
	{
		File file = new File("Z:/JavaFileOperations");
		if (file.exists())
		{
			System.out.println("Directory was found.");
			for (int i = 1; i <= 10; ++i)
			{
				File txtFile = new File("Z:/JavaFileOperations/file_" + i + ".txt");
				boolean b = txtFile.delete();
				if (b)
				{
					System.out.println("file_" + i + ".txt was successfully deleted.");
				}
				else
				{
					System.out.println("file_" + i + ".txt couldn't be deleted.");
				}
			}
		}
		else
		{
			System.out.println("Directory couldn't be found.");
		}
	}
	public static void main(String[] args)
	{
		createTenFiles();
		deleteTenFiles();
	}
}
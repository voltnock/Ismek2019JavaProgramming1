import java.io.File;
import java.io.IOException;

public class Example6
{
	public static void main(String[] args)
	{
		File file = new File("Z:/JavaFileOperations/ISMEK");
		boolean b = file.mkdir();
		if (b)
		{
			System.out.println("ISMEK folder has been created.");
		}
		else
		{
			System.out.println("ISMEK folder couldn't be created.");
		}
		file = new File("Z:/JavaFileOperations/JavaSE.txt");
		try
		{
			b = file.createNewFile();
		}
		catch (IOException e)
		{
			e.printStackTrace();
		}
		System.out.println("Has the file been created? " + b);
	}
}
import java.util.Scanner;
public class Example2
{
	public static double Calc(double num1, double num2, String opp)
	{
		double result = 0;
		switch (opp)
		{
		case "+":
			result = num1 + num2;
			break;
		case "-":
			result = num1 - num2;
			break;
		case "*":
			result = num1 * num2;
			break;
		case "/":
			result = num1 / num2;
			break;
		}
		return result;
	}
	public static void main(String[] args)
	{
		System.out.println("Enter '+' for add, '-' for substract, '*' for multiply or '/' for divide:");
		Scanner scn = new Scanner(System.in);
		String opp = scn.next();
		System.out.println("Enter the 1st number for calculation:");
		double num1 = scn.nextDouble();
		System.out.println("Enter the 2nd number for calculation:");
		double num2 = scn.nextDouble();
		scn.close();
		System.out.println(num1 + opp + num2 + "=" + Calc(num1, num2, opp));
	}
}
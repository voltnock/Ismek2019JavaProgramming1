public class Example1
{
	public static String acrostic(String[] words)
	{
		String result = "";
		for (int i = 0; i < words.length; ++i)
		{
			result += words[i].charAt(0);
		}
		return result;
	}
	public static void main(String[] args)
	{
		String[] arr = {"Sam", "Henric", "Eric", "Ronald", "Indie", "Fabien", "Fabiola"};
		System.out.println(acrostic(arr));
	}
}
import java.util.Scanner;
public class Example4
{
	public static double CircleArea(double radius)
	{
		return Math.PI * radius * radius;
	}
	public static double CircleCircumference(double radius)
	{
		return 2 * Math.PI * radius;
	}
	public static void main(String[] args)
	{
		Scanner scn = new Scanner(System.in);
		System.out.println("Enter the circle's radius:");
		double radius = scn.nextDouble();
		scn.close();
		System.out.println("Circle's area = " + CircleArea(radius));
		System.out.println("Circle's circumference = " + CircleCircumference(radius));
	}
}
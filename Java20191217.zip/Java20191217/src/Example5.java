import java.util.Scanner;
public class Example5
{
	public static double SquareArea(double length)
	{
		return length * length;
	}
	public static double SquareCircumference(double length)
	{
		return 4 * length;
	}
	public static void main(String[] args)
	{
		Scanner scn = new Scanner(System.in);
		System.out.println("Enter the square's side length:");
		double length = scn.nextDouble();
		scn.close();
		System.out.println("Square's area = " + SquareArea(length));
		System.out.println("Square's circumference = " + SquareCircumference(length));
	}
}
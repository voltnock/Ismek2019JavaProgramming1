public class Example3
{
	public static void Range(int start, int end)
	{
		for (int i = start; i <= end; ++i)
		{
			if (i != end)
			{
				System.out.print(i + ", ");
			}
			else
			{
				System.out.print(i);
			}
		}
	}
	public static void main(String[] args)
	{
		Range(25, 37);
	}
}
import java.util.Scanner;
public class Example9
{
	public static String Reverse(String wrd)
	{
		String result = "";
		for (int i = wrd.length() - 1; i >= 0; --i)
		{
			result += wrd.charAt(i);
		}
		return result;
	}
	public static void main(String[] args)
	{
		Scanner scn = new Scanner(System.in);
		System.out.println("Enter a word to be reversed:");
		String word = scn.nextLine();
		scn.close();
		System.out.println(word + " is " + Reverse(word) + " when reversed.");
	}
}
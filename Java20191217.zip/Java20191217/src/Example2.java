public class Example2
{
	public static double operNum(double a, double b, char c)
	{
		double result = 0;
		if (c == '+')
		{
			result =  a + b;
		}
		else if (c == '-')
		{
			result =  a - b;
		}
		else if (c == '*')
		{
			result =  a * b;
		}
		else if (c == '/')
		{
			result =  a / b;
		}
		return result;
	}
	public static String operText(double a, double b, char c)
	{
		String str = "error";
		if (c == '+')
		{
			str = a + " + " + b + " = ";
		}
		else if (c == '-')
		{
			str = a + " - " + b + " = ";
		}
		else if (c == '*')
		{
			str =  a + " * " + b + " = ";
		}
		else if (c == '/')
		{
			str = a + " / " + b + " = ";
		}
		return str;
	}
	public static void operWrite(double a, double b, char c)
	{
		System.out.print(operText(a, b, c));
		System.out.println(operNum(a, b, c));
	}
	public static void main(String[] args)
	{
		operWrite(3.5, 8.2, '+');
		operWrite(30, 8, '-');
		operWrite(60, 7, '*');
		operWrite(700, 35, '/');
		Example1 example1 = new Example1();
		example1.writeText(); //Public method is accessed.
	}
}
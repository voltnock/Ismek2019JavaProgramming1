import java.util.Scanner;
public class Example6
{
	public static double RectangleArea(double length, double width)
	{
		return length * width;
	}
	public static double RectangleCircumference(double length, double width)
	{
		return 2 * (length + width);
	}
	public static void main(String[] args)
	{
		Scanner scn = new Scanner(System.in);
		System.out.println("Enter the rectangle's length:");
		double length = scn.nextDouble();
		System.out.println("Enter the rectangle's width:");
		double width = scn.nextDouble();
		scn.close();
		System.out.println("Rectangle's area = " + RectangleArea(length, width));
		System.out.println("Rectangle's circumference = " + RectangleCircumference(length, width));
	}
}
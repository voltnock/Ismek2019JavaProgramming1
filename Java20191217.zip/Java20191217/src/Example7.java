public class Example7
{
	public static double MinValue(double number1, double number2)
	{
		double min = 0;
		if (number1 < number2)
		{
			min = number1;
		}
		else if (number2 < number1)
		{
			min = number2;
		}
		return min;
	}
	public static double MaxValue(double number1, double number2)
	{
		double min = 0;
		if (number1 > number2)
		{
			min = number1;
		}
		else if (number2 > number1)
		{
			min = number2;
		}
		return min;
	}
	public static void main(String[] args)
	{
		System.out.println(MinValue(20,35));
		System.out.println(MaxValue(40,10));
	}
}
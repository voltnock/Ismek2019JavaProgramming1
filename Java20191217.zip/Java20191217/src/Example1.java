public class Example1 //Methods Usage
{
	public static double sumNum(double a, double b)
	{
		return a + b;
	}
	public static String sumText(double a, double b)
	{
		return a + " + " + b + " = ";
	}
	public static void sumWrite(double a, double b)
	{
		System.out.print(sumText(a, b));
		System.out.println(sumNum(a, b));
	}
	public void writeText()
	{
		System.out.println("I have written a text.");
	}	
	public static void main(String[] args)
	{
		sumWrite(3.5, 7.2);
		Example1 example1 = new Example1();
		example1.writeText();
	}
}
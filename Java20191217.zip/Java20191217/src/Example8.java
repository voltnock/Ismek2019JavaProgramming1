import java.util.Scanner;
public class Example8
{
	public static int charCounter(String a, char c)
	{
		int result = 0;
		for (int i = 0; i < a.length(); ++i)
		{
			if (a.charAt(i) == c)
			{
				++result;
			}
		}
		return result;
	}
	public static void main(String[] args)
	{
		Scanner scn = new Scanner(System.in);
		System.out.println("Enter case sensitive character to be searched for in text:");
		String searchChrStr = scn.next();
		scn.close();
		char searchChar = searchChrStr.charAt(0);
		String text = "Java Programming Course";
		System.out.println(text +  " contains " + charCounter(text, searchChar) + " time(s) character " + searchChar);
	}
}
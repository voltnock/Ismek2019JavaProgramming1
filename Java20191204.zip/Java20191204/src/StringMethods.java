public class StringMethods {
	public static void main(String[] args) {
		/*
		charAt				returns the character at thespecified index of String
		contains			searches a text in the String if the text is contained, case sensitive, returns boolean
		endsWith			returns boolean if the String ends with the specified text
		startsWith			returns boolean if the String starts with the specified text
		equals				compares two String if they are equal, case sensitive, returns boolean
		equalsIgnoreCase	compares two String if they are equal, ignoring case, returns boolean
		indexOf				specifies the first index of seached text in String, returns int, if text is not included in String, retuns -1
		lastIndexOf			specifies the last index of seached text in String, returns int, if text is not included in String, retuns -1
		isEmpty				returns boolean if the String is empty (Empty String is not null, null means not defined)
		length				returns int specifying the length of the String
		replace				replaces text in String by receiving (text to be searched for and new text) as parameters
		split				splits String into Strings. Example: split String into Strings whenever encountering comma
		substring			returns String which starts from specified index and ends with specified index, or just starts with specified index
		toUpperCase			converts the String's letters to all UPPER Case, returns String
		toLowerCase			converts the String's letters to all lower Case, returns String
		toString			converts Object to String
		trim				trims the leading and last spaces of the String
		valueOf				converts any data type to String
		format				used to build a String using parameters
		*/
		String str = "";
		System.out.println(str.isEmpty());
		}
}
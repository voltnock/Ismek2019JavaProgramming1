public class Example4 {
	public static void main(String[] args) {
		String website = "www.google.com";
		if (website.startsWith("www."))
		{
			System.out.println(website + " starts with www.");
		}
		else
		{
			System.out.println(website + " doesn't start with www.");
		}
		if (website.endsWith(".com"))
		{
			System.out.println(website + " ends with .com");
		}
		else
		{
			System.out.println(website + " doesn't end with .com");
		}
	}
}
public class Example5 {
	public static void main(String[] args) {
		String text = "Muvaffakiyetsizle�tiricile�tiriveremeyebileceklerimizdenmi�sinizcesine";
		System.out.println("\"" + text + "\"" + " word is " + text.length() + " characters long.");
		System.out.println("----------");
		String text2 = "  Today is cold.       ";
		System.out.println(text2);
		String text3 = text2.trim();
		System.out.println(text3);
		String text4 = text3.replace("cold", "warm");
		System.out.println(text4);
		System.out.println("----------");
		String str = "T�RK�YE B�Y�K M�LLET MECL�S�";
		String[] arr = str.split(" ");
		for (int i = 0; i < arr.length; ++i)
		{
			System.out.println(arr[i]);
		}
		System.out.println("----------");
		String fruits = "apple,pear,cherry,pomegranate,orange";
		String[] fruit = fruits.split(",");
		for (int i = 0; i < fruit.length; ++i)
		{
			System.out.println(fruit[i]);
		}
		System.out.println("----------");
		String email = "contact@google.com";
		String[] mail = email.split("@");
		System.out.println(mail[0]);
		System.out.println(mail[1]);
		System.out.println("----------");
		String text5 = "";
		if (text5.isEmpty())
		{
			System.out.println("text5 is empty.");
		}
		else
		{
			System.out.println("text5 is not empty.");
		}
	}
}
public class Example3 {
	public static void main(String[] args) {
		String city = "Istanbul";
		if ("istanbul".equals(city)) //compares case sensitive
		{
			System.out.println("City is istanbul");
		}
		else
		{
			System.out.println("City is not istanbul.");
		}
		String city2 = "ANKARA";
		if ("ankara".equalsIgnoreCase(city2)) //compares ignoring case
		{
			System.out.println("City is ankara.");
		}
		else
		{
			System.out.println("City is not ankara.");
		}
	}
}
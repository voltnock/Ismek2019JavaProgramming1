public class Example2 {
	public static void main(String[] args) {
		String school = "Fatih Software School";
		System.out.println(school.toUpperCase());
		System.out.println(school.toLowerCase());
		System.out.println(school);
		school = school.toUpperCase(); //school has been modified
		System.out.println(school);
		System.out.println("----------");
		String text = "YUNAN�STANBULGAR�STAN";
		String text2 = text.substring(5, 13);
		System.out.println(text2);
		System.out.println("----------");
		String weathercondition = "Today is very cold.";
		if (weathercondition.contains("very"))
		{
			System.out.println("very is included");
		}
		else
		{
			System.out.println("very is not included");
		}
	}
}
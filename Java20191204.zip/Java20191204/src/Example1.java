public class Example1 {
	public static void main(String[] args) {
		//Type conversion: explicit (casting) and implicit convert
		//Example: in order not to lose decimals, convert from int to float
		int num = 65;
		System.out.println(num);
		//ASCII character codes
		char ch = (char) num; //explicit conversion
		System.out.println(ch);
		System.out.println("-----");
		double num2 = 512.9;
		System.out.println(num2);
		int num2_i = (int) num2; //implicit conversion
		System.out.println(num2_i);
		System.out.println("-----");
		String num3 = "100";
		int num4 = Integer.parseInt(num3); //explicit conversion
		System.out.println(num4);
		System.out.println("-----");
		String num5 = "320.2";
		double num6 = Double.parseDouble(num5);
		float num7 = Float.parseFloat(num5);
		System.out.println("num6 = " + num6 + " num7 = " + num7);
		System.out.println("-----");
		int num8 = 5963;
		String num9 = String.valueOf(num8);
		//String.valueOf() is used to convert the inside value to String
		System.out.println("num9 = " + num9);
	}
}
public class Ders20191201E {
	public static void main(String[] args) {
		//Ge�ici de�i�ken kullan�m�
		int A = 100;
		int B = 500;
		int gecici = 0;
		System.out.println("A = " + A);
		System.out.println("B = " + B);
		System.out.println("--------");
		gecici = A;
		A = B;
		B = gecici;
		System.out.println("A = " + A);
		System.out.println("B = " + B);
	}
}
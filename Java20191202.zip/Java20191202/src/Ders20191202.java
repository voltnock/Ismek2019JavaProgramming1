import java.util.Scanner;
public class Ders20191201 {
	public static void main(String[] args) {
		//Klavyeden veri almak i�in
		Scanner sc = new Scanner(System.in);
		System.out.println("L�tfen ad�n�z� giriniz:"); //Bo�luk karakterine kadar okur.
		String ad = sc.next();
		System.out.println("L�tfen soyad�n�z� giriniz:");
		String soyad = sc.next();
		System.out.println("L�tfen ya��z� giriniz:");
		int yas = sc.nextInt(); //nextInt
		System.out.println("Ad: " + ad + " Soyad: " + soyad + " Ya�: " + yas);
		System.out.println("L�tfen tam ad�n�z� giriniz:");
		String tamad = sc.nextLine(); //Bo�luk dahil t�m sat�r� okur.
		System.out.println("Tam Ad: " + tamad);
	}
}
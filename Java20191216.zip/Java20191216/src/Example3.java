import java.util.Scanner;
public class Example3
{
	public static void main(String[] args)
	{
		System.out.println("Enter a word which includes a few A's or a's"); 
		Scanner scn = new Scanner(System.in);
		String word = scn.nextLine();
		scn.close();
		String result = "";
		for (int i = 0; i < word.length(); ++i)
		{
			if (word.charAt(i) != 'a' && word.charAt(i) != 'A')
			{
				result += word.charAt(i);
			}
		}
		System.out.println(result);
	}
}
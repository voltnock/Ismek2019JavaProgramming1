import java.util.Scanner;
public class Example5
{
	public static void main(String[] args)
	{
		//Find how many vowels entered word contains
		String vowels = "aeiou";
		Scanner scn = new Scanner(System.in);
		System.out.println("Please enter a word");
		String word = scn.next().toLowerCase(); //for easy comparison
		scn.close();
		int counter = 0;
		for (int i = 0; i < word.length(); ++i)
		{
			for (int j = 0; j < vowels.length(); ++j)
			{
				if (word.charAt(i) == vowels.charAt(j))
				{
					++counter;
					break;
				}
			}
		}
		if (counter >= 1)
		{
			System.out.println(word + " has " + counter + " vowels.");			
		}
		else
		{
			System.out.println(word + " has no vowels.");
		}
	}
}
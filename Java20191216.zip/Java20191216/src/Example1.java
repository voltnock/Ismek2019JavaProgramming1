import java.util.Scanner;
public class Example1
{
	public static void main(String[] args)
	{
		System.out.println("Enter your full name without spaces:");
		Scanner scn = new Scanner(System.in);
		String name = scn.nextLine();
		scn.close(); //Closes Scanner scn
		String lowerUpper = "";
		for (int i = 0; i < name.length(); ++i)
		{
			if (i % 2 == 1)
			{
				lowerUpper += String.valueOf(name.charAt(i)).toLowerCase();
			}
			else
			{
				lowerUpper += String.valueOf(name.charAt(i)).toUpperCase();
			}
		}
		System.out.println(lowerUpper);
	}
}
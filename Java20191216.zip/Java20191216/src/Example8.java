import java.util.Scanner;
public class Example8
{
	public static void main(String[] args)
	{
		//Assign the numbers to the numbers array
		Scanner scn = new Scanner(System.in);
		int length = 5;
		String[] arr = new String[length];
		int[] numArr = new int[length];
		for (int i = 0; i < arr.length; ++i)
		{
			System.out.println("Enter value: " + (i + 1) + " out of " + length);
			arr[i] = scn.nextLine();
		}
		scn.close();
		int counter = 0;
		String numbers = "0123456789";
		for (int i = 0; i < arr.length; ++i)
		{
			int flag = 0;
			for (int j = 0; j < arr[i].length(); ++j)
			{
				for (int k = 0; k < numbers.length(); ++k)
				{
					if (arr[i].charAt(j) == numbers.charAt(k))
					{
						++flag;
					}
				}
				if (arr[i].length() == flag)
				{
					numArr[counter] = Integer.parseInt(arr[i]);
					++counter;
				}
			}
		}
		for (int i = 0; i < numArr.length; ++i)
		{
			if (numArr[i] != 0)
			{
				System.out.println(numArr[i]);
			}
		}
	}
}
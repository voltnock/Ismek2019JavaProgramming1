import java.util.Scanner;
public class Example6
{
	public static void main(String[] args)
	{
		//Sort numbers in ascending order
		Scanner scn = new Scanner(System.in);
		int[] arr = new int[5];
		for (int i = 0; i < arr.length; ++i)
		{
			System.out.println("Enter number " + (i + 1));
			arr[i] = scn.nextInt();
		}
		scn.close();
		int temp = 0;
		for (int i = 0; i < arr.length; ++i)
		{
			for (int j = i + 1; j < arr.length; ++j)
			{
				if (arr[i] > arr[j])
				{
					temp = arr[i];
					arr[i] = arr[j];
					arr[j] = temp;
				}
			}
		}
		for (int i : arr)
		{
			System.out.print(i + ", ");
		}
		
	}
}
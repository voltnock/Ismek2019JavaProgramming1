import java.util.Scanner;
public class Example7
{
	public static void main(String[] args)
	{
		//How many A's or a's and E's or e's in String
		Scanner scn = new Scanner(System.in);
		System.out.println("Enter a few words:");
		String str = scn.nextLine();
		scn.close();
		int counterA = 0, counterE = 0;
		for (int i = 0; i < str.length(); ++i)
		{
			if (str.charAt(i) == 'A' || str.charAt(i) == 'a')
			{
				++counterA;
			}
			else if (str.charAt(i) == 'E' || str.charAt(i) == 'e')
			{
				++counterE;
			}
		}
		System.out.println(str + " has " + counterA + " A's or a's and " + counterE + " E's or e's.");
	}
}
import java.util.Scanner;
public class Example2
{
	public static void main(String[] args)
	{
		System.out.println("Enter integer to calculate its factorial:");
		Scanner scn = new Scanner(System.in);
		long num = scn.nextLong();
		scn.close();
		long fact = 1;
		if (num < 0)
		{
			System.out.println("Entered number must be at least 0");
		}
		else if (num == 0)
		{
			fact = 1;
			System.out.println(num + "! = " + fact);
		}
		else
		{
			for (int i = 1; i <= num; ++i)
			{
				fact *= i;
			}
			System.out.println(num + "! = " + fact);
		}
		long counter = 1;
		long fc = 1;
		while (counter <= num)
		{
			fc *= counter;
			++counter;
		}
		System.out.println(num + "! = " + fc);
	}
}
import java.util.Random; //10 eleman tek �ift toplam
public class Example4
{
	public static void main(String[] args)
	{
		Random rnd = new Random();
		int[] numbers = new int[10];
		for (int i = 0; i < numbers.length; ++i)
		{
			numbers[i] = rnd.nextInt(100);
			if (i != numbers.length - 1)
			{
				System.out.print(numbers[i] + ", ");
			}
			else
			{
				System.out.print(numbers[i]);
			}
		}
		int evenSum = 0, oddSum = 0, evenCounter = 0, oddCounter = 0, evenCounter2 = 0, oddCounter2 = 0;
		for (int i = 0; i < numbers.length; ++i)
		{
			if (numbers[i] % 2 == 0)
			{
				evenSum += numbers[i];
				++evenCounter;				
			}
			else
			{
				oddSum += numbers[i];
				++oddCounter;
			}
		}
		int[] evenNums = new int[evenCounter];
		int[] oddNums = new int[oddCounter];
		for (int i = 0; i < numbers.length; ++i)
		{
			if (numbers[i] % 2 == 0)
			{
				evenNums[evenCounter2] = numbers[i];
				++evenCounter2;
			}
			else
			{
				oddNums[oddCounter2] = numbers[i];
				++oddCounter2;
			}
		}
		System.out.print("\nEven numbers: ");
		for (int i : evenNums)
		{
			System.out.print(i + ", ");
		}
		System.out.print("\nOdd numbers: ");
		for (int i : oddNums)
		{
			System.out.print(i + ", ");
		}
		System.out.println("\nSum of even numbers = " + evenSum);
		System.out.println("Sum of odd numbers = " + oddSum);
	}
}
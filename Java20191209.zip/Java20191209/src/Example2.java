import java.util.Random;
public class Example2 {
	public static void main(String[] args) {
		Random rnd = new Random(); //Creating a new object rnd, whose type is Random Class
		int num1 = rnd.nextInt(); //Can return negative or positive integer
		System.out.println(num1);
		int num2 = rnd.nextInt(50); //Returns integer between 0 and 50, 50 is not included
		System.out.println(num2);
	}
}
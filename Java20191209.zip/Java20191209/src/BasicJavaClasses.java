public class BasicJavaClasses {
	public static void main(String[] args) {
		//Exmaple 1 - Math
		double pi = Math.PI;
		System.out.println("Pi number = " + pi);
		double e = Math.E;
		System.out.println("Euler number = " + e);
		double min = Math.min(10, 90);
		System.out.println("Minimum number = " + min);
		double max = Math.max(50, 80);
		System.out.println("Maximum number = " + max);
		double rndNum = Math.random(); //Random decimal between 0 and 1
		System.out.println("Random number = " + rndNum);
		double ceil = Math.ceil(1578.14); //Rounds to upper integer
		System.out.println("Rounded number = " + ceil);
		double floor = Math.floor(150.70); //Eliminates decimal part of number
		System.out.println("Number's decimal part eliminated = " + floor);
		double absValue = Math.abs(50.7); //Absolute Value
		System.out.println("Absolute value = " + absValue); 
		double sqrt = Math.sqrt(10.8); //Square root
		System.out.println("Square root = " + sqrt);
		double round = Math.round(45.5);
		//If decimal part is greater than or equal to 0.5, rounds to upper integer, otherwise, rounds to lower integer
		System.out.println("Rounded with round = " + round);
	}
}
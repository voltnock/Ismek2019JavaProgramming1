import java.time.DayOfWeek;
import java.time.LocalDate;
public class Example5 {
	public static void main(String[] args) {
		LocalDate date = LocalDate.now();
		System.out.println("Date = " + date.toString());
		System.out.println("Year = " + date.getYear());
		System.out.println("Month = " + date.getMonth()); //Word
		System.out.println("Month = " + date.getMonthValue()); //Number
		System.out.println("Date = " + date.getDayOfMonth());
		System.out.println("Date of Year = " + date.getDayOfYear());
		DayOfWeek dayWeek = date.getDayOfWeek();
		System.out.println("Day of week = " + dayWeek.getValue());
	}
}
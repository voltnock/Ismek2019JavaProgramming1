import java.util.Calendar;
import java.util.Date;
import java.util.GregorianCalendar;
public class Example6{
	public static void main(String[] args) {
		Calendar cal = new GregorianCalendar();
		System.out.println(cal.getTime());
		System.out.println(cal.getTimeInMillis()); //Timestamp, 1575897929661
		System.out.println(cal.getCalendarType()); //Returns calendar type
		Date date = cal.getTime();
		System.out.println(date.getDate()); //striked out because old dated
		System.out.println(date.getHours());
		System.out.println(date.getMinutes());
		System.out.println("Timestamp: " + date.getTime());
	}
}
import java.util.Random;
import java.util.Scanner;
public class Example4 {
	static Random rnd;
	public static int createNumber(int maxNum)
	{
		return rnd.nextInt(maxNum);
	}
	public static void main(String[] args) {
		rnd = new Random();
		int num = createNumber(5);
		Scanner sc = new Scanner(System.in);
		System.out.println("Guess the number between 0 and 5, 5 exclusive.");
		int trial = sc.nextInt();
		if (trial < num)
		{
			System.out.println("Your guess is lower than the number, the number was: " + num);
		}
		else if (trial == num)
		{
			System.out.println("Congratulations! You won, the number was: " + num);
		}
		else
		{
			System.out.println("Your guess is greater than the number, the number was: " + num);
		}
	}
}
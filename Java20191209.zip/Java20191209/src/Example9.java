import java.util.Scanner;
public class Example9 {
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		double num = 0;
		System.out.println("Please enter a number:");
		try
		{
			num = sc.nextDouble();
		}
		catch (java.util.InputMismatchException e)
		{
			System.out.println(e.toString());
		}
		catch (Exception e)
		{
			System.out.println("num = " + num); //Doesn't work
		}
		System.out.println("num = " + num);
	}
}
import java.util.Random;
public class Example3 {
	//Here is Global area
	static Random rnd; //added static keyword to be compatible with public static void main
	//Method with type returns a value, Method with void does not return value.
	public static int createNumber(int maxNum)
	{
		return rnd.nextInt(maxNum);
	}
	public static void main(String[] args) {
		rnd = new Random();
		int num1 = createNumber(20);
		int num2 = createNumber(10);
		System.out.println("num1 = " + num1 + ", num2 = " + num2);
		if (num1 < num2)
		{
			System.out.println("num1 is less than num2");
		}
		else if (num1 == num2)
		{
			System.out.println("The numbers are equal");
		}
		else
		{
			System.out.println("num1 is greater than num2");
		}
	}
}
public class Example10 {
	public static void main(String[] args) {
		int num1 = 5;
		int num2 = 0;
		try
		{
			int result = num1 / num2; //Divided by zero
		}
		catch (ArithmeticException e)
		{
			System.out.println("Divided by zero error.");
		}
	}
}
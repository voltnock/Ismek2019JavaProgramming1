import java.text.SimpleDateFormat;
import java.time.LocalDateTime; //up to date class
import java.time.chrono.Chronology;
import java.util.Calendar;
import java.util.GregorianCalendar;
public class Example7 {
	public static void main(String[] args) {
		LocalDateTime localDateTime = LocalDateTime.now();
		System.out.println("Year = " + localDateTime.getYear());
		System.out.println("Month = " + localDateTime.getMonthValue());
		System.out.println("Date = " + localDateTime.getDayOfMonth());
		System.out.println("Hour = " + localDateTime.getHour());
		System.out.println("Minute = " + localDateTime.getMinute());
		System.out.println("Second = " + localDateTime.getSecond());
		System.out.println("Milliseond = " + (localDateTime.getNano()) / 1000000);
		System.out.println("Day of year = " + localDateTime.getDayOfYear());
		System.out.println("Day of week = " + localDateTime.getDayOfWeek());
		Chronology chronology = localDateTime.getChronology();
		System.out.println("Chronological calendar type = " + chronology.getCalendarType());
		//SimpleDateFormat is a class used to format a date in a specified format.
		//We can use SimpleDateFormat to convert a string to date format
		/*SimpleDateFormat includes parameters:
		d - date,  M - month  y or Y - year */
		Calendar cal = new GregorianCalendar();
		SimpleDateFormat sdf = new SimpleDateFormat("dd.MM.YYY HH:mm");
		String oldDate = cal.toString();
		String newDate = sdf.format(cal.getTime());
		System.out.println("Unformatted date = " + oldDate);
		System.out.println("Formatted date = " + newDate);
		// format "2020.01.10 12:05" to "dd.MM.YYY HH:mm"
	}
}
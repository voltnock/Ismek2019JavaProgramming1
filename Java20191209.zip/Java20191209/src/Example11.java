public class Example11 {
	public static void main(String[] args) {
		String text = "Hello";		
		try
		{
			System.out.println(text.charAt(20));
		}
		catch (StringIndexOutOfBoundsException e)
		{
			System.out.println("It is out of length of String.");
		}
	}
}
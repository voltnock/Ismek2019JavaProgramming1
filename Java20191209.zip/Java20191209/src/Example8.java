import java.util.Scanner;
import java.util.Random;
public class Example8 {
	public static void main(String[] args) {
		//Exception Handling
		try
		{
			//The block where we add codes that may cause error. Used to prevent program from ending with error.
			//Codes added in try, enable program to continue ignoring errors.
			
		}
		catch (Exception e)
		{
			//handle exception if error occurs. If an error occurs, this block is used.
			//More than one catch block can be built. Catch Blocks' class names should be unique.
			//Exception class is used for catching all types of errors.
			//If there are more than one catch blocks and Exception class will be used,
			//Exception class should be used as the last catch block, because catch blocks later than a catch block with
			//Exception class name catch block will not work.
		}
		finally
		{
			//Optional block.
			//Works whether there are error(s) or not.
		}
	}
}
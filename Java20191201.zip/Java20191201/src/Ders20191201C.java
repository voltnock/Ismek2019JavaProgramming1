import java.util.Scanner;
public class Ders20191201C {
	public static void main(String[] args) {
		/* Operat�rler
		 * Aritmetik Operat�rler
		 * + topla - ��kar * �arp / b�l % mod ++ 1 art�r -- 1 azalt
		 * Mant�ksal Operat�rler
		 * || veya && ve ! de�il
		 * Atama ve E�itlik Operat�rleri
		 * = atama == de�er e�itli�ini kontrol etmek < k���kt�r > b�y�kt�r <= k���k e�it >= b�y�k e�it
		 * === (Java'da yoktur, denklik kontrol� (de�er ve tip))
		 * += de�i�kene topla ve ata -= de�i�kenden ��kar ve ata *= de�i�keni �arp ve ata /= de�i�keni b�l ve ata
		 * %= de�i�kenin modunu al ve ata != e�it de�il */
		//+ operat�r�n�n kullan�m�
		//+ �ncesi ve sonras� String ise String elde edilir.
		String ad = "�erif";
		String soyad = "G�ng�r";
		String adSoyad = ad + " " + soyad;
		System.out.println(adSoyad);
		//+ �ncesi ve sonras� String ve String olmayan t�r ise, yine String elde edilir.
		String sinif = "Bili�im Okulu";
		int sinifNo = 9;
		String yeniDeger = sinif + sinifNo;
		System.out.println(yeniDeger);
		//+ �ncesi ve sonras� say� ise, toplama yap�l�r.
		int sayi1 = 50;
		int sayi2 = 60;
		int toplam = sayi1 + sayi2;
		System.out.println("Toplam: " + toplam);
		//-----
		Scanner sc = new Scanner(System.in);
		System.out.println("1. say�y� giriniz: ");
		int sayiA = sc.nextInt();
		System.out.println("2. say�y� giriniz: ");
		int sayiB = sc.nextInt();
		System.out.println(sayiA + " + " + sayiB + " = " + (sayiA + sayiB));
		System.out.println(sayiA + " - " + sayiB + " = " + (sayiA - sayiB));
		System.out.println(sayiA + " * " + sayiB + " = " + (sayiA * sayiB));
		System.out.println(sayiA + " / " + sayiB + " = " + (sayiA / sayiB));
		System.out.println(sayiA + " % " + sayiB + " = " + (sayiA % sayiB));
		System.out.println("----------");
		int sonucToplam = sayiA + sayiB;
		int sonucFark = sayiA - sayiB;
		int sonucCarpim = sayiA * sayiB;
		int sonucBolum = sayiA / sayiB;
		int sonucMod = sayiA % sayiB;
		System.out.println("Toplam = " + sonucToplam);
		System.out.println("Fark = " + sonucFark);
		System.out.println("Carpim = " + sonucCarpim);
		System.out.println("Bolum = " + sonucBolum);
		System.out.println("Mod = " + sonucMod);
		System.out.println("----------");
		int s = 10;
		System.out.println(s++); //�nce yazd�r, sonra art�r
		System.out.println(s--); //�nce yazd�r, sonra azalt
		System.out.println(++s); //�nce art�r, sonra yazd�r
		System.out.println(--s); //�nce azalt, sonra yazd�r
		int topla = s += 1;
		int cikar = s -= 1;
		int carp = s *= 5;
		int bol = s /= 2;
		System.out.println("Toplam = " + topla);
		System.out.println("Fark = " + cikar);
		System.out.println("Carpim = " + carp);
		System.out.println("Bolum = " + bol);
	}
}
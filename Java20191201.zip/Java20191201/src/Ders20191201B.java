import java.util.Scanner;
public class Ders20191201B {
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		System.out.println("1. say�y� giriniz:");
		int sayi1 = sc.nextInt();
		System.out.println("2. say�y� giriniz:");
		int sayi2 = sc.nextInt();
		System.out.println("1. say� = " + sayi1);
		System.out.println("2. say� = " + sayi2);
	}
}
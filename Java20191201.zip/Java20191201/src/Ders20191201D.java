public class Ders20191201D {
	public static void main(String[] args) {
		boolean b = false;
		if (b == false)
		{
			System.out.println("b'nin de�eri false'tur.");
		}
		else
		{
			System.out.println("b'nin de�eri true'dur.");
		}
		if (!b) //true de�eri, if blo�unu �al��t�r�r
		{
			System.out.println("b'nin de�eri true'dur.");
		}
		int sayi1 = 5;
		int sayi2 = 9;
		if (sayi1 != sayi2)
		{
			System.out.println("Say�lar e�it de�ildir.");
		}
		if (sayi1 == sayi2)
		{
			System.out.println("Say�lar e�ittir.");
		}
		if (sayi1 > sayi2)
		{
			System.out.println("Say�1 b�y�kt�r.");
		}
		if (sayi1 < sayi2)
		{
			System.out.println("Say�1 k���kt�r.");
		}
		if (sayi1 >= sayi2)
		{
			System.out.println("Say�1 b�y�k veya e�ittir.");
		}
		if (sayi1 <= sayi2)
		{
			System.out.println("Say�1 k���k veya e�ittir.");
		}
		if (sayi1 == 5 && sayi2 == 9)
		{
			//T�m �artlar sa�lanmal�
		}
		if (sayi1 == 5 || sayi2 == 9)
		{
			//�artlardan en az herhangi biri sa�lanmal�
		}
	}
}
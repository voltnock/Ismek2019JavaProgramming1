public class Ders20191203A {
	public static void main(String[] args) {
		/* if statement and switch case structure
		 * if; if, else; if, else if, else
		 */
		int num = 1;
		if (num == 1)
		{
			System.out.println("num variable's value is 1");
		}
		int num2 = 5;
		if (num2 == 7)
		{
			System.out.println("num2 variable's value is 7");
		}
		else if (num2 ==5)
		{
			System.out.println("num2 variable's value is 5");
		}
		else
		{
			System.out.println("num2 variable's value is neither 7 nor 5.");
		}
		
	}
}
import java.util.Scanner;
class Ders20191203F {
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter season name");
		String season = sc.next();
		if (season.equalsIgnoreCase("Spring"))
		{
			System.out.println("March");
			System.out.println("April");
			System.out.println("May");
		}
		else if (season.equalsIgnoreCase("Summer"))
		{
			System.out.println("June");
			System.out.println("July");
			System.out.println("August");
		}
		else if (season.equalsIgnoreCase("Autumn") || season.equalsIgnoreCase("Fall"))
		{
			System.out.println("September");
			System.out.println("October");
			System.out.println("November");
		}
		else if (season.equalsIgnoreCase("Winter"))
		{
			System.out.println("December");
			System.out.println("January");
			System.out.println("February");
		}
		else
		{
			System.out.println("Wrong data input.");
		}
	}
}
import java.util.Scanner;
public class Ders20191203D {
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		System.out.println("Select your calculation: Type one of these: add sub mul div");
		String calc = sc.nextLine();
		System.out.println("Enter the 1st number:");
		int num1 = sc.nextInt();
		System.out.println("Enter the 2nd number:");
		int num2 = sc.nextInt();
		if (calc.equals("add"))
		{
			System.out.println(num1 + " + " + num2 + " = " + (num1 + num2));
		}
		else if (calc.equals("sub"))
		{
			System.out.println(num1 + " - " + num2 + " = " + (num1 - num2));
		}
		else if (calc.equals("mul"))
		{
			System.out.println(num1 + " * " + num2 + " = " + (num1 * num2));
		}
		else if (calc.equals("div"))
		{
			System.out.println(num1 + " / " + num2 + " = " + (num1 / num2));
		}
		else
		{
			System.out.println("Wrong data supplied.");
		}
	}
}
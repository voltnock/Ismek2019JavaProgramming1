import java.util.Scanner;
public class Ders20191203J {
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		System.out.println("Select your calculation: Type one of these: add sub mul div");
		String calc = sc.nextLine();
		System.out.println("Enter the 1st number:");
		double num1 = sc.nextDouble();
		System.out.println("Enter the 2nd number:");
		double num2 = sc.nextDouble();
		switch (calc) {
		case "add":
			System.out.println(num1 + " + " + num2 + " = " + (num1 + num2));
			break;
		case "sub":
			System.out.println(num1 + " - " + num2 + " = " + (num1 - num2));
			break;
		case "mul":
			System.out.println(num1 + " * " + num2 + " = " + (num1 * num2));
			break;
		case "div":
			System.out.println(num1 + " / " + num2 + " = " + (num1 / num2));
			break;
		default:
			System.out.println("Wrong data supplied.");
			break;
		}
	}
}
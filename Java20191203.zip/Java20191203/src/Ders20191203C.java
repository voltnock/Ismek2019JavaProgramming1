import java.util.Scanner;
public class Ders20191203C {
	public static void main(String[] args) {
		//Ask for name and age, if below 13, write age is youger than 13, write for 20, >20 - <25, 25, 26+
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter your name:");
		String name = sc.nextLine();
		System.out.println("Enter your age:");
		int age = sc.nextInt();
		if (age < 13)
		{
			System.out.println(name + ", You are younger than 13.");
		}
		else if (age == 20)
		{
			System.out.println(name + ", You are 20 years old.");
		}
		else if (age > 20 && age < 25)
		{
			System.out.println(name + ", Your age is between 20 and 25.");
		}
		else if (age == 25)
		{
			System.out.println(name + ", You are 25 years old.");
		}
		else if (age > 25)
		{
			System.out.println(name + ", You are older than 25.");
		}
		else
		{
			System.out.println(name + ", Your age is not in the designated interval.");
		}
	}
}
import java.util.Scanner;
public class Ders20191203E {
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter your first name");
		String firstName = sc.nextLine();
		System.out.println("Enter your family name:");
		String familyName = sc.nextLine();
		if ("�ER�F".equals(firstName) && "G�NG�R".equals(familyName))
		{
			System.out.println("Enter your age:");
			int age = sc.nextInt();
			if (age == 25)
			{
				System.out.println("You are 25 years old.");
			}
			else
			{
				System.out.println("You are not 25 years old.");
			}
		}
		else
		{
			System.out.println("Wrong data input.");
		}
	}
}
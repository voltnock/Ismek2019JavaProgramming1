import java.util.Scanner;
public class Ders20191203B {
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter your username:");		
		String username = sc.nextLine(); //Reads whole line including spaces
		System.out.println("Enter your password:");		
		String password = sc.next(); //Reads characters until space or end of line
		String storedUsername = "root";
		String storedPassword = "abcd";
		//Simple data types are compared with ==. We need String Class' equals method to compare two String's.
		//Strings and Objects are not simple data types.
		if (username.equals(storedUsername) && password.equals(storedPassword))
		{
			System.out.println("Welcome, you have logged in.");
		}
		else
		{
			System.out.println("You have supplied bad credentials.");
		}		
	}
}
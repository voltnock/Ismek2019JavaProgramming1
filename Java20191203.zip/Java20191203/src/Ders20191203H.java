import java.util.Scanner;
class Ders20191203H {
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter season name");
		String season = sc.next();
		switch (season) {
		case "Spring":
			System.out.println("March");
			System.out.println("April");
			System.out.println("May");
			break; //If break is forgotten, other case blocks operate, too. break is used to end a loop.
		case "Summer":
			System.out.println("June");
			System.out.println("July");
			System.out.println("August");
			break;
		case "Autumn":
			System.out.println("September");
			System.out.println("October");
			System.out.println("November");
			break;
		case "Fall":
			System.out.println("September");
			System.out.println("October");
			System.out.println("November");
			break;
		case "Winter":
			System.out.println("December");
			System.out.println("January");
			System.out.println("February");
			break;
		default:
			System.out.println("Wrong data input.");
			break;
		}
	}
}
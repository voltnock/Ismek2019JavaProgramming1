public class Ornek1 { //class ismi ile dosya ismi ayn� olmal� (Ornek1.java)
	public static void main(String[] args) {
		//tek yorum sat�r�
		/*
		 * birden fazla yorum sat�r�
		 */
		//syso yaz�p Ctrl + Space k�sayolu ile System.out.println(); ifadesi yaz�l�r.
		System.out.print("�smek, Fatih Bili�im Okulu");
		System.out.print("9 nolu derslik");
		System.out.println("Java"); //new line
		System.out.println("Standard");
		System.out.println("Edition");
		System.out.print("�smek, Fatih Bili�im Okulu\n");
		System.out.println("9 nolu derslik");
		System.out.println(true);
		System.out.println(false);
		System.out.println(1);
		System.out.println(7.45);
		System.out.println('A');
		System.out.println("Merhaba");
		//de�i�ken kullan�m� de�i�ken ismi k���k harfle ba�lamal�
		//De�i�ken: Belirli tipteki de�erlerin ram bellek �zerinde saklanmas� i�lemini sa�layan yap�lard�r. De�i�kenler belirli tiplerde de�er saklayabilir.
		//De�i�kenler ile saklad���m�z de�erleri �a��rmak i�in de�i�ken ismine ihtiya� duyar�z.
		//Her de�i�ken tipi, RAM bellek �zerinde belirli uzunluklarda de�er saklayabilir.
		//De�i�ken olu�turma: Bir class i�erisinde bir de�i�ken bir defa �retilebilir. De�i�ken ismi kopyalanamaz.
		int sayi1 = 5; //tamsay� saklar
		double d = 1.5d; //double sonuna d harfi eklenebilir veya eklenmeyebilir. Ondal�k say�d�r.
		float f = 7.42f; //float sonuna f harfi eklenmelidir. Ondal�k say�d�r.
		char ch = 'A'; //Bir harakter saklar.
		String yazi = "Merhaba D�nya!"; //Java'da String tip b�y�k harfle ba�lar ��nk� referans tiptir. Metin saklar.
		boolean b = true; //Mant�ksal true veya false de�eri saklar.
		long l = 1234567890; //B�y�k tamsay� saklar.
		short s1 = 32767; //-32768 ila +32767 tamsay� saklar.
		short s2 = -32768;
		byte b1 = 127; //-128 ila +127 tamsay� saklar.
		byte b2 = -128;
		//De�i�ken ve metot isimleri kurallar�:
		//De�i�ken ve metot isimlerinin ilk karakteri �zellikle k���k harle ba�lar.
		//Rakam ile ba�layamaz.
		//�zel karakter i�eremez.
		//T�rk�e karakter i�ermemelidir. ��nk� derleme zaman�nda T�rk�e karakter desteklemeyen cihazda hata ��kar.
		System.out.println("-----");
		System.out.println(sayi1);
		System.out.println(d);
		System.out.println(f);
		System.out.println(ch);
		System.out.println(yazi);
		System.out.println(b);
		System.out.println(l);
		System.out.println(s1);
		System.out.println(s2);
		System.out.println(b1);
		System.out.println(b2);
	}
}
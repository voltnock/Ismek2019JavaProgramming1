public class Example3
{
	static void multiplicationTable(int num)
	{
		for (int i = 1; i <= 10; ++i)
		{
			System.out.println(i + " * " + num + " = " + (num * i));
		}
	}
	public static void main(String[] args)
	{
		for (int i = 1; i < 10; ++i)
		{
			System.out.println("Multiplication table for " + i);
			multiplicationTable(i);
		}		
	}
}
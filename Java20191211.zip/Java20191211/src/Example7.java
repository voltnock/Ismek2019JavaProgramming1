public class Example7
{
	static void createPyramid(char chr)
	{
		for (int i = 10; i > 0; --i)
		{
			int b;
			for (b = 0; b < i; ++b)
			{
				System.out.print(" ");
			}
			for (int j = b; j < 10; ++j)
			{
				System.out.print(chr + " ");
			}
			System.out.println("");
		}
	}
	static void createPyramidNumber(int lng)
	{
		for (int i = 0; i <= lng; ++i)
		{
			for (int j = 0; j <= lng - i; ++j)
			{
				System.out.print(" ");
			}
			for (int k = 0; k <= i; ++k)
			{
				System.out.print(k + " ");
			}
			System.out.println("");
		}
	}
	public static void main(String[] args)
	{
		createPyramid('#');
		createPyramidNumber(8);
	}
}
import java.util.Scanner;
public class Example1 {
	public static void main(String[] args) {
		Scanner scn = new Scanner(System.in);
		int num = 4;
		String[] arr = new String[num];
		for (int i = 0; i < num; ++i)
		{
			System.out.println("Enter the word order " + (i + 1));
			arr[i] = String.valueOf(scn.nextLine().charAt(0));
		}
		StringBuilder wordBuild = new StringBuilder();
		for (int i = 0; i < arr.length; ++i)
		{
			wordBuild.append(arr[i]);
		}
		String word = wordBuild.toString();
		System.out.println(word);
		String newWord = "";
		for (String i : arr)
		{
			newWord += i;
		}
		System.out.println(newWord);
	}
}
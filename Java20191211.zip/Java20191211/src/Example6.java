public class Example6
{
	public static void main(String[] args)
	{
		int size = 9;
		char chr = '#';
		for (int i = 0; i < size - 1; ++i)
		{
			for (int j = size - i - 1; j > 0; --j)
			{
				System.out.print(" ");
			}
			for (int k = 0; k < i; ++k)
			{
				System.out.print(chr);
			}
			for (int j = 0; j <= i; ++j)
			{
				System.out.print(chr);
			}
			if (i != size - 1)
			{
				System.out.println("");
			}
		}
		for (int i = 0; i < size; ++i)
		{
			for (int j = 0; j < i; ++j)
			{
				System.out.print(" ");
			}
			for (int k = size - i - 1; k > 0; --k)
			{
				System.out.print(chr);
			}
			for (int j = i; j < size; ++j)
			{
				System.out.print(chr);
			}
			if (i != size)
			{
				System.out.println("");
			}
		}
	}
}
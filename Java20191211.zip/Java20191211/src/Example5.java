public class Example5
{
	public static void main(String[] args)
	{
		int size = 6;
		for (int i = 0; i < size; ++i)
		{
			for (int j = size - i - 1; j > 0; --j)
			{
				System.out.print(" ");
			}
			for (int k = 0; k <= i; ++k)
			{
				System.out.print("*");
			}
			if (i != size)
			{
				System.out.println("");
			}
		}
		for (int i = 0; i < size; ++i)
		{
			for (int j = 0; j <= i; ++j)
			{
				System.out.print("*");
			}
			if (i != size)
			{
				System.out.println("");
			}
		}
		for (int i = 0; i < size - 1; ++i)
		{
			for (int j = i; j < size; ++j)
			{
				System.out.print("*");
			}
			if (i != size - 1)
			{
				System.out.println("");
			}
		}
		for (int i = 0; i < size; ++i)
		{
			for (int j = 0; j < i; ++j)
			{
				System.out.print(" ");
			}
			for (int k = size - i; k > 0; --k)
			{
				System.out.print("*");
			}
			if (i != size)
			{
				System.out.println("");
			}
		}
	}
}
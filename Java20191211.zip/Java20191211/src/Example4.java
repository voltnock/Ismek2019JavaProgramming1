import java.util.Random;
public class Example4
{
	public static void main(String[] args)
	{
		Random rnd = new Random();
		int[] arr = new int[10];
		for (int i = 0; i < 10; ++i)
		{
			arr[i] = rnd.nextInt(1001);
		}
		for (int i = 0; i < arr.length; ++i)
		{
			if (i != (arr.length - 1))
			{
				System.out.print(arr[i] + ", ");
			}
			else
			{
				System.out.println(arr[i]);
			}
		}
		System.out.println("----------");
		int counterEven1 = 0, counterOdd1 = 0, counterEven2 = 0, counterOdd2 = 0;
		System.out.println("Even numbers in array");
		for (int i = 0; i < arr.length; ++i)
		{
			if(arr[i] % 2 == 0)
			{
				++counterEven1;
			}
		}
		for (int i = 0; i < arr.length; ++i)
		{
			if(arr[i] % 2 == 0)
			{
				if (i != (arr.length - 1) && counterEven2 < counterEven1 - 1)
				{
					System.out.print(arr[i] + ", ");
					++counterEven2;
				}
				else
				{
					System.out.println(arr[i]);
				}
			}
		}
		System.out.println("----------");
		System.out.println("Odd numbers in array");
		for (int i = 0; i < arr.length; ++i)
		{
			if(arr[i] % 2 != 0)
			{
				++counterOdd1;
			}
		}
		for (int i = 0; i < arr.length; ++i)
		{
			if(arr[i] % 2 != 0)
			{
				if (i != (arr.length - 1) && counterOdd2 < counterOdd1 - 1)
				{
					System.out.print(arr[i] + ", ");
					++counterOdd2;
				}
				else
				{
					System.out.println(arr[i]);
				}
			}
		}
		System.out.println("----------");
	}
}
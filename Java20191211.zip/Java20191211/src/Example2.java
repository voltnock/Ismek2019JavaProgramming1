import java.util.Scanner;
public class Example2 {
	public static void main(String[] args) {
		System.out.println("Enter a word:");
		Scanner scn = new Scanner(System.in);
		String word = scn.nextLine();
		for (int i = 0; i < word.length(); ++i)
		{
			System.out.println(word.charAt(i));
		}
	}
}
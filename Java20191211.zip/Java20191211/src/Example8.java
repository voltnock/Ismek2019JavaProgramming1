import java.util.Scanner;
public class Example8
{
	public static void main(String[] args)
	{
		Scanner scn = new Scanner(System.in);
		double[] arr = new double[5];
		for (int i = 0; i < arr.length; ++i)
		{
			System.out.println("Enter number " + (i + 1));
			arr[i] = scn.nextDouble();			
		}
		double sum = 0;
		for (int i = 0; i < arr.length; ++i)
		{
			sum += arr[i];			
		}
		System.out.println("Sum = " + sum);
	}
}